<?php
$con=mysqli_connect("localhost","root","","login_signup_db");
?>